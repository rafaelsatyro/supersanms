$(document).ready(function () {
  $('.btnSaibaMais').click(function() {
    $('html, body').animate({
      scrollTop: $(".sectionSaibaMais").offset().top
    }, 1000)
  });

  $('.btnComprar').click(function() {
    $('html, body').animate({
      scrollTop: $(".sectionComprar").offset().top
    }, 1000)
  });

  $('.btnCompraAdicional').click(function() {
    $('html, body').animate({
      scrollTop: $(".sectionCompraAdicional").offset().top
    }, 1000)
  });
});